import addTitleIcon from "@assets/images/add-title-icon-16.svg";
import arrowPointingOutIconHover from "@assets/images/arrows-pointing-out-icon-hover.svg";
import arrowPointingOutIcon from "@assets/images/arrows-pointing-out-icon.svg";
import closeIconHover from "@assets/images/close-icon-hover.svg";
import closeIcon from "@assets/images/close-icon.svg";
import dateIcon from "@assets/images/date-icon-16.svg";
import earthTimeIcon from "@assets/images/erth-time-icon.svg";
import refreshIcon from "@assets/images/refresh-icon.svg";
import timeIcon from "@assets/images/time-icon-16.svg";
import BaseModal from "@components/ui/BaseModal";
import GuestTag, { type Guest } from "@components/ui/calendar/GuestTag";
import ColorSingleSelect from "@components/ui/form/Select2ColorOption";
import Select2Wrapper from "@components/ui/form/Select2Wrapper";
import SubmitButton from "@components/ui/form/SubmitButton";
import InteractiveIcon from "@components/ui/InteractiveIcon";
import TimerList from "@components/ui/Modals/CalendarEventModal/TimerList";
import { useFlatpickrMonthDropdown } from "@components/ui/useFlatpickrMonthDropdown";
import { useCalendar } from "@context/CalendarContext";
import { useContacts } from "@context/index";
import { useMailUI } from "@context/MailUIContext";
import { useCalendarEventForm } from "@hooks/useCalendarEventForm";
import { useRecurrence } from "@hooks/useRecurringForm";
import addPesionIcon from "@images/add-pesion-icon.svg";
import descriptionIcon from "@images/description-icon-16.svg";
import linkIcon from "@images/link-icon-16.svg";
import locationIcon from "@images/location-icon.svg";
import { createEvent, editEvent } from "@services/calendar/calendarService";
import { generateTimeOptions } from "@utils/calendarUtil";
import { formatDate, formatTime24HrFrom12HrString, parseDateForFlatpickr, TimeFormat } from "@utils/dateUtil";
import { filterGuestByEmail, normalizeGuests } from "@utils/guestUtil";
import { useEffect, useRef } from "react";
import Flatpickr from 'react-flatpickr';
import { Controller, useWatch } from "react-hook-form";
import SimpleBar from 'simplebar-react';
import { colorListConfi } from "../../../../config/fullCalendar.config";

const timezoneOptions = [
    { value: "UTC", label: "GMT +00:00 — UTC" },
    { value: "Asia/Kolkata", label: "GMT +05:30 — Asia/Kolkata" },
    { value: "America/New_York", label: "GMT -05:00 — America/New_York" },
    { value: "Europe/London", label: "GMT +00:00 — Europe/London" },
    { value: "Asia/Dubai", label: "GMT +04:00 — Asia/Dubai" },
    { value: "Asia/Tokyo", label: "GMT +09:00 — Asia/Tokyo" },
    { value: "Australia/Sydney", label: "GMT +10:00 — Australia/Sydney" }
];

interface CalendarEventModalProps {
    modalId: string;
    zIndex: number;
    // Pass anything you want through openModal
    info?: any;
    title?: string;
    startDate?: string;
    endDate?: string;
    guestsList?: string[];
    location?: string;
    meetingLink?: string;
    description?: string;
    timeZone?: string;
    recurrence?: any;
    [key: string]: any;
}

export function getISTRoundedStartEndTime(
    isoDateTime?: string,
    intervalMinutes = 15
): { startTime: string; endTime: string } {
    if (!isoDateTime) {
        return { startTime: '', endTime: '' };
    }

    // 1️⃣ Parse ISO with offset correctly
    const parsed = new Date(isoDateTime);
    if (isNaN(parsed.getTime())) {
        return { startTime: '', endTime: '' };
    }

    const istDate = new Date(
        parsed.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })
    );

    const intervalMs = intervalMinutes * 60 * 1000;
    const roundedStart = new Date(
        Math.round(istDate.getTime() / intervalMs) * intervalMs
    );

    const roundedEnd = new Date(roundedStart.getTime() + intervalMs);

    const formatHHMM = (d: Date) =>
        `${String(d.getHours()).padStart(2, '0')}:${String(
            d.getMinutes()
        ).padStart(2, '0')}`;

    return {
        startTime: formatHHMM(roundedStart),
        endTime: formatHHMM(roundedEnd),
    };
}

function CalendarEventModal({ modalId, zIndex, ...props }: CalendarEventModalProps) {
    const { contacts } = useContacts();
    const { closeModal, openModal } = useMailUI();
    const { getAllEventList, selectedEvent } = useCalendar();
    const pendingEditDataRef = useRef<any>(null);
    const { startTime, endTime } = getISTRoundedStartEndTime(props.dateStr);

    const {
        control,
        handleSubmit,
        reset,
        watch,
        setValue,
        getValues,
    } = useCalendarEventForm();

    useEffect(() => {
        if (!props?.isEdit) return;
        if (!startTime || !endTime) return;

        setValue('eventStartTime', startTime, { shouldDirty: false });
        setValue('eventEndTime', endTime, { shouldDirty: false });

    }, [startTime, endTime, setValue]);

    const eventStartDate = useWatch({
        control,
        name: 'eventStartDate',
    });

    const {
        getSelectValue,
        onChange: onRecurrenceChange,
        buildPayload
    } = useRecurrence({ setValue, openModal, eventStartDate });

    const guestsList = useWatch({
        control,
        name: 'guestsList',
    });

    const getMinEndDate = () => {
        if (!eventStartDate) return undefined;

        const [year, month, day] = eventStartDate.split('-').map(Number);
        const localStart = new Date(year, month - 1, day);
        localStart.setHours(0, 0, 0, 0);

        return localStart;
    };

    const eventStartTime = useWatch({
        control,
        name: 'eventStartTime',
    });

    const guests: Guest[] = normalizeGuests(guestsList);

    const onRemoveGuest = (email: string) => {
        const current = getValues("guestsList") || [];
        setValue("guestsList", filterGuestByEmail(current, email), { shouldDirty: true });
    };

    // Reset/populate form when modal opens or props change
    useEffect(() => {
        if (props?.isEdit) {
            // Normalize guestsList to ensure all entries are strings
            const normalizedGuests = Array.isArray(props.guestList)
                ? props.guestList.map(g => typeof g === 'string' ? g : g.email || '').filter(Boolean)
                : [];

            reset({
                title: props.title || '',
                eventStartDate: props.startDate ? formatDate(props.startDate, TimeFormat.YYYYMMDD) as string : '',
                eventEndDate: props.endDate ? formatDate(props.endDate, TimeFormat.YYYYMMDD) as string : '',
                allDayCheckbox: !!props.allDay,
                eventStartTime: props.startTime || '',
                eventEndTime: props.endTime || '',
                eventLocation: props.location || '',
                eventMeetingLink: props.meetingLink || '',
                eventDescription: props.eventDescription || '',
                eventTimeZone: props.timeZone || 'Asia/Kolkata',
                guestsList: normalizedGuests,
                eventColor: props.eventColor || '',
                recurrence: props.recurrence?.isCustom
                    ? "custom"
                    : (props.recurrence?.type ?? "doesNotRepeat")
            });
        } else if (props?.date) {
            reset({
                eventStartDate: formatDate(props.date, TimeFormat.YYYYMMDD) as string,
                eventEndDate: formatDate(props.date, TimeFormat.YYYYMMDD) as string,
                allDayCheckbox: !!props.allDay,
            });
        } else {
            reset();
        }
        return () => {
            reset();
        };
    }, [props?.isEdit, props?.date, reset]);

    const onClose = () => {
        reset();
        closeModal(modalId);
        // Close parent info modal if it exists
        if (props?.parentModalId) {
            closeModal(props.parentModalId);
        }
    };

    const formatDateForCalendarEvent = (date: string | Date | undefined) => {
        if (!date) return '';

        if (date instanceof Date) {
            return date.toISOString().split('T')[0];
        }

        const dateObj = new Date(date);
        return isNaN(dateObj.getTime()) ? '' : dateObj.toISOString().split('T')[0];
    };

    const onSubmit = async (data: any) => {
        const recurrencePayloadString = buildPayload(data.recurrence);

        // Transform form data to match backend requirements
        const payload = {
            title: data.title,
            startDate: formatDateForCalendarEvent(data.eventStartDate),
            endDate: (() => {
                const date = new Date(data.eventEndDate);
                return formatDateForCalendarEvent(date);
            })(),
            startTime: formatTime24HrFrom12HrString(data.eventStartTime),
            endTime: formatTime24HrFrom12HrString(data.eventEndTime),
            allDayCheckbox: data.allDayCheckbox,
            location: data.eventLocation || '',
            meetingLink: data.eventMeetingLink || '',
            description: data.eventDescription || '',
            timeZone: data.eventTimeZone,
            eventColor: data.eventColor,
            recurrence: recurrencePayloadString,
            sendMailToGuest: data.sendMailToGuest,
            guest: data.guestsList ? data.guestsList.join(',') : ''
        };

        if (props?.isEdit) {
            const selectedEventDateValue = selectedEvent?.selectedEventDate;
            const editEventDate = selectedEventDateValue
                ? (() => {
                    const d = new Date(selectedEventDateValue as any);
                    return isNaN(d.getTime()) ? undefined : d;
                })()
                : undefined;

            const editPayload = {
                eventId: selectedEvent?.id || '',
                title: data.title,
                eventColor: data.eventColor,
                startDate: formatDateForCalendarEvent(data.eventStartDate),
                endDate: formatDateForCalendarEvent(data.eventEndDate),
                startTime: formatTime24HrFrom12HrString(data.eventStartTime),
                endTime: formatTime24HrFrom12HrString(data.eventEndTime),
                allDayCheckbox: data.allDayCheckbox,
                recurrence: recurrencePayloadString ? JSON.parse(recurrencePayloadString) : null,
                guestsList: data.guestsList,
                location: data.eventLocation || '',
                meetingLink: data.eventMeetingLink || '',
                description: data.eventDescription || '',
                attachments: data.attachments || [],
                editEventDate,
                eventEditType: '',
                type: "update"
            };

            if (recurrencePayloadString) {
                pendingEditDataRef.current = editPayload;
                const recurrenceData = JSON.parse(recurrencePayloadString);
                openModal('recurrenceModal', {
                    onConfirm: (eventEditType: 'thisEvent' | 'thisAndFollowingEvent' | 'allEvent') => {
                        const pendingEditData = pendingEditDataRef.current;
                        if (!pendingEditData) {
                            console.error('No pending edit data available');
                            return;
                        }

                        const editPayload = {
                            ...pendingEditData,
                            eventEditType,
                        };

                        editEvent(editPayload).then((response) => {
                            if (response.statusCode === 200) {
                                getAllEventList();
                                onClose();
                            }
                        }).catch((error) => {
                            console.error('Error editing event:', error);
                        });
                    },
                    initialData: recurrenceData,
                });
            } else {
                editPayload.eventEditType = 'originalEvent';
                const response = await editEvent(editPayload);
                if (response.statusCode === 200) {
                    getAllEventList();
                    onClose();
                }
            }
            return;
        }

        // Handle form submission here
        const response = await createEvent(payload);
        if (response.statusCode === 200) {
            // Refresh events from context
            getAllEventList();
            onClose();
        }
    };

    const timeOptions15 = generateTimeOptions({ interval: 15 });

    useEffect(() => {
        if (!eventStartTime) return;
        const startIndex = timeOptions15.indexOf(eventStartTime);
        if (startIndex === -1) return;
        const currentEndTime = getValues('eventEndTime');
        if (!currentEndTime) return;
        const endIndex = timeOptions15.indexOf(currentEndTime);
        if (endIndex === -1) return;
        // If end time is same or before start time → reset it
        if (endIndex <= startIndex) {
            setValue('eventEndTime', '', { shouldDirty: true });
        }

    }, [eventStartTime, timeOptions15, getValues, setValue]);

    const endTimeMinSequence = (() => {
        if (!eventStartTime) return undefined;
        const startIndex = timeOptions15.indexOf(eventStartTime);
        if (startIndex === -1) return undefined;
        return startIndex + 1;
    })();

    const startFromMonth = new Date().getMonth();
    const mountMonthDropdown = useFlatpickrMonthDropdown(startFromMonth);

    return (
        <BaseModal
            isOpen={true}
            onClose={onClose}
            zIndex={zIndex}
            className=""
            closeOnBackdrop={true}
            closeOnEsc={true}
            draggable={true}
            dragHandleSelector=".drag-handle"
            width="min(100vw, 640px)"
        >
            <div
                className="calendar-event-modal search-bar-work"
                id="eventModal"
                style={{ zIndex }}
                role="dialog"
                aria-modal="true"
            >
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content modal-box-shadow-c1 max-w-640">
                        <div className="modal-header drag-handle">
                            <button className="expand-btn btn hover-link icon-hover-effect drag-handle-btn">
                                <InteractiveIcon
                                    defaultIcon={arrowPointingOutIcon}
                                    hoverIcon={arrowPointingOutIconHover}
                                    activeIcon=""
                                    isActive={false}
                                    alt=""
                                    className="interactive-icon hover-image"
                                    renderAs="img"
                                    tooltip="Move"
                                />
                            </button>
                            <h5 className="modal-title modal-title-center" id="eventModalTitle"> {props?.isEdit ? 'Edit Event' : 'Create new event'}</h5>
                            <button type="button" className="btn-close hover-link btn  icon-hover-effect" onClick={onClose}>
                                <InteractiveIcon
                                    defaultIcon={closeIcon}
                                    hoverIcon={closeIconHover}
                                    activeIcon=""
                                    isActive={false}
                                    alt=""
                                    className="interactive-icon hover-image"
                                    renderAs="img"
                                    tooltip="Close"
                                />
                            </button>
                        </div>
                        <div className="modal-body p-0" >
                            <SimpleBar
                                className="CalendarModalSimpleBar"
                                autoHide={false}
                                forceVisible="y"
                            >
                                <div className="calendar-event-modal-body p-16 pb-0">
                                    <div className="d-block">
                                        <div className="form-group m-0 mb-2 d-flex align-items-center justify-content-between">
                                            <label className="control-label mb-0">Title</label>
                                        </div>
                                        <div className="d-flex align-items-center">
                                            <div className="form-group mb-3 w-100 me-3">
                                                <div className="input-icon-add">
                                                    <Controller
                                                        name="title"
                                                        control={control}
                                                        render={({ field }) => (
                                                            <input
                                                                type="text"
                                                                className="form-control"
                                                                id="title"
                                                                {...field}
                                                            />
                                                        )}
                                                    />
                                                    <img src={addTitleIcon} alt="" className="input-icon-1" />
                                                </div>
                                            </div>
                                            <div className="form-group mb-3 form-row color-pik select2-color-pick color-pik">
                                                <div className="input-control">
                                                    <Controller
                                                        name="eventColor"
                                                        control={control}
                                                        render={({ field }) => {
                                                            const selectedOption =
                                                                colorListConfi.find(opt => opt.value === field.value) ?? null;

                                                            return (
                                                                <ColorSingleSelect
                                                                    value={selectedOption}
                                                                    options={colorListConfi}
                                                                    onChange={(option) => {
                                                                        field.onChange(option?.value ?? "");
                                                                    }}
                                                                />
                                                            );
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row time-cntrol">
                                            <div className="form-group m-0 mb-2 px-2 d-flex align-items-center justify-content-between">
                                                <label className="control-label mb-0">
                                                    Date, time &amp; repeat event
                                                </label>
                                                <a href="javascript:;" className="fs-12 send-bcc show-time-zone d-none">
                                                    Show time zone
                                                </a>
                                            </div>
                                            <div className="col-md-6 p-0 d-flex flex-wrap">
                                                <div className="col-md-6">
                                                    <div className="form-group mb-2">
                                                        <div className="input-icon-add custom-datepicker-month-selector-c2-vm">
                                                            <Controller
                                                                name="eventStartDate"
                                                                control={control}
                                                                render={({ field }) => (
                                                                    <Flatpickr
                                                                        value={parseDateForFlatpickr(field.value)}
                                                                        id="eventStartDate"
                                                                        onChange={(dates: Date[]) => {
                                                                            const date = dates[0];
                                                                            if (date) {
                                                                                const isoString = date.toISOString().split('T')[0];
                                                                                field.onChange(isoString);
                                                                            } else {
                                                                                field.onChange('');
                                                                            }
                                                                        }}
                                                                        options={{
                                                                            mode: 'single',
                                                                            dateFormat: 'd-m-Y',
                                                                            allowInput: false,
                                                                            onReady: (_, __, instance) => mountMonthDropdown(instance)
                                                                        }}
                                                                        className="form-control DateRangePickerStaticTop datepickermodal"
                                                                        placeholder="Select date range"
                                                                    />
                                                                )}
                                                            />
                                                            <img
                                                                src={dateIcon}
                                                                alt=""
                                                                className="input-icon-1"
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className={`col-md-6 all-day-time-show-hid ${watch('allDayCheckbox') ? 'd-none' : ''}`} id="eventStartTimeSection">
                                                    <div className="form-group mb-2">
                                                        <div className="input-icon-add position-relative custom-datepicker-month-selector-c2-vm">
                                                            <Controller
                                                                name="eventStartTime"
                                                                control={control}
                                                                defaultValue="05:00 PM"
                                                                render={({ field }) => (
                                                                    <TimerList
                                                                        value={field.value || ''}
                                                                        onChange={field.onChange}
                                                                        options={timeOptions15}
                                                                    />
                                                                )}
                                                            />
                                                            <img src={timeIcon} alt="" className="input-icon-1" />
                                                        </div>
                                                        <div className="custom-time-dropdown-container" id="eventStartTimeDropdown"></div>
                                                    </div>
                                                </div>
                                                <div className="col-md-6 ">
                                                    <div className="form-group mb-2">
                                                        <div className="input-icon-add custom-datepicker-month-selector-c2-vm">
                                                            <Controller
                                                                name="eventEndDate"
                                                                control={control}
                                                                render={({ field }) => {
                                                                    return (
                                                                        <Flatpickr
                                                                            value={parseDateForFlatpickr(field.value)}
                                                                            onChange={(dates: Date[]) => {
                                                                                const date = dates[0];
                                                                                if (date) {
                                                                                    // Use local date conversion to avoid timezone offset issues
                                                                                    const localYear = date.getFullYear();
                                                                                    const localMonth = String(date.getMonth() + 1).padStart(2, '0');
                                                                                    const localDay = String(date.getDate()).padStart(2, '0');
                                                                                    const localDateString = `${localYear}-${localMonth}-${localDay}`;
                                                                                    field.onChange(localDateString);
                                                                                } else {
                                                                                    field.onChange('');
                                                                                }
                                                                            }}
                                                                            options={{
                                                                                mode: 'single',
                                                                                dateFormat: 'd-m-Y',
                                                                                allowInput: false,
                                                                                minDate: getMinEndDate(),
                                                                                onReady: (_, __, instance) => mountMonthDropdown(instance)

                                                                            }}
                                                                            className="form-control DateRangePickerStaticTop datepickermodal"
                                                                            placeholder="Select enddate"
                                                                        />
                                                                    );
                                                                }}
                                                            />
                                                            <img src={dateIcon} alt="" className="input-icon-1" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className={`col-md-6 all-day-time-show-hid ${watch('allDayCheckbox') ? 'd-none' : ''}`} id="eventEndTimeSection">
                                                    <div className="form-group mb-2">
                                                        <div className="input-icon-add position-relative">
                                                            <Controller
                                                                name="eventEndTime"
                                                                control={control}
                                                                render={({ field }) => (
                                                                    <TimerList
                                                                        key={`endTime-${field.value}-${endTimeMinSequence}`}
                                                                        value={field.value || ''}
                                                                        onChange={field.onChange}
                                                                        options={timeOptions15}
                                                                        minSequence={endTimeMinSequence}
                                                                    />
                                                                )}
                                                            />
                                                            <img src={timeIcon} alt="" className="input-icon-1" />
                                                        </div>
                                                        <div className="custom-time-dropdown-container" id="eventEndTimeDropdown"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-6 px-2 d-flex flex-wrap">
                                                <div className="col-md-12 timezone-box">
                                                    <div className="form-group mb-2 form-row">
                                                        <div className="input-control">
                                                            <div className="input-icon-add">
                                                                <img src={earthTimeIcon} alt="" className="input-icon-1" />
                                                                <Controller
                                                                    name="eventTimeZone"
                                                                    control={control}
                                                                    render={({ field }) => (
                                                                        <Select2Wrapper
                                                                            value={field.value || "Asia/Kolkata"}
                                                                            onChange={field.onChange}
                                                                            options={timezoneOptions}
                                                                            isMulti={false}
                                                                            isModal={true}
                                                                        />
                                                                    )}
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    className="col-md-12 timezone-box d-none"
                                                    id="eventEndTimezone"
                                                >
                                                    <div className="form-group form-row mb-2">
                                                        <div className="input-control">
                                                            <div className="input-icon-add">
                                                                <img src={earthTimeIcon} alt="" className="input-icon-1" />
                                                                <Controller
                                                                    name="eventTimeZone"
                                                                    control={control}
                                                                    render={({ field }) => (
                                                                        <Select2Wrapper
                                                                            value={field.value || "Asia/Kolkata"}
                                                                            onChange={field.onChange}
                                                                            options={timezoneOptions}
                                                                            isMulti={false}
                                                                            isModal={true}
                                                                        />
                                                                    )}
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row time-cntrol mb-3 justify-content-between">
                                            <div className="col-md-2  d-flex align-items-center">
                                                <div className="form-group m-0 mb-2 d-flex align-items-center">
                                                    <div className="mail-received-check-btn me-2">
                                                        <div className="checkbox-custom table-check">
                                                            <Controller
                                                                name="allDayCheckbox"
                                                                control={control}
                                                                render={({ field }) => (
                                                                    <input
                                                                        className="list-child"
                                                                        type="checkbox"
                                                                        id="all-day-checkbox"
                                                                        checked={field.value}
                                                                        onChange={field.onChange}
                                                                    />
                                                                )}
                                                            />
                                                            <label
                                                                htmlFor="all-day-checkbox"
                                                                className="label-text"
                                                            />
                                                        </div>
                                                    </div>
                                                    <label
                                                        htmlFor="all-day-checkbox"
                                                        className="control-label m-0 all-day-checkbox"
                                                    >
                                                        All Day
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row time-cntrol mb-3 justify-content-between">
                                            <div className="col-md-6">
                                                <div className="form-group mb-2 form-row does-not-repeat-box">
                                                    <div className="input-control">
                                                        <div className="input-icon-add">
                                                            <img src={refreshIcon} alt="" width={16} height={16} className="input-icon-1" />
                                                            <Controller
                                                                name="recurrence"
                                                                control={control}
                                                                render={({ field }) => (
                                                                    <Select2Wrapper
                                                                        value={getSelectValue(field.value)}
                                                                        onChange={onRecurrenceChange}
                                                                        options={[
                                                                            { label: "Does not repeat", value: "doesNotRepeat" },
                                                                            { label: "Daily", value: "daily" },
                                                                            { label: "Weekly", value: "weekly" },
                                                                            { label: "Monthly", value: "monthly" },
                                                                            { label: "Yearly", value: "yearly" },
                                                                            { label: "Custom", value: "custom" },
                                                                        ]}
                                                                        isMulti={false}
                                                                        isModal={true}
                                                                    />
                                                                )}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                className="col-auto ends-on-box d-none"
                                                id="customRecurrenceStringBox"
                                            >
                                                <div className="form-group mb-2">
                                                    <div className="input-icon-add d-flex align-items-center justify-content-start">
                                                        <span id="customRecurrenceString" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="d-block guests-section-calendar po">
                                            <div className="form-group form-row select2-profile mb-2">
                                                <label className="control-label">Guests</label>
                                                <div className="input-control">
                                                    <div className="input-icon-add">
                                                        <img src={addPesionIcon} alt="" width={16} height={16} className="input-icon-1" />
                                                        <Controller
                                                            name="guestsList"
                                                            control={control}
                                                            render={({ field }) => (
                                                                <Select2Wrapper
                                                                    value={field.value || []}
                                                                    onChange={field.onChange}
                                                                    options={contacts}
                                                                    placeholder="Select or type to add"
                                                                    isMulti={true}
                                                                    isModal={true}
                                                                />
                                                            )}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="form-group  mb-2">
                                                <div className="">
                                                    <div className="mt-2 d-block selected-tags-addmail mb-3">
                                                        <SimpleBar
                                                            className="gustsTagsScrollbar"
                                                            autoHide={false}
                                                            forceVisible="y"
                                                        >
                                                        {guests.length > 0
                                                            && guests.map((guest, index) => (
                                                                <GuestTag
                                                                    key={`${guest.email}-${index}`}
                                                                    guest={guest}
                                                                    mode="edit"
                                                                    onRemove={onRemoveGuest}
                                                                />
                                                            ))
                                                        }
                                                        </SimpleBar>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row time-cntrol ">
                                            <div className="col-md-6">
                                                <div className="form-group">
                                                    <label htmlFor="location" className="control-label">
                                                        Location
                                                    </label>
                                                    <div className="input-icon-add">
                                                        <img src={locationIcon} alt="" width={16} height={16} className="input-icon-1" />
                                                        <Controller
                                                            name="eventLocation"
                                                            control={control}
                                                            render={({ field }) => (
                                                                <input
                                                                    type="text"
                                                                    className="form-control"
                                                                    id="location"
                                                                    placeholder="Add location"
                                                                    {...field}
                                                                />
                                                            )}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-6">
                                                <div className="form-group">
                                                    <label htmlFor="meetingLink" className="control-label"> Meeting Link </label>
                                                    <div className="input-icon-add">
                                                        <img src={linkIcon} alt="" className="input-icon-1" />
                                                        <Controller
                                                            name="eventMeetingLink"
                                                            control={control}
                                                            render={({ field }) => (
                                                                <input
                                                                    type="text"
                                                                    className="form-control"
                                                                    id="meetingLink"
                                                                    placeholder="Add meeting link"
                                                                    {...field}
                                                                />
                                                            )}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row time-cntrol ">
                                            <div className="form-group px-2 description">
                                                <label htmlFor="description" className="control-label">
                                                    Description
                                                </label>
                                                <div className="input-icon-add">
                                                    <img src={descriptionIcon} alt="" className="input-icon-1" />
                                                    <Controller
                                                        name="eventDescription"
                                                        control={control}
                                                        render={({ field }) => (
                                                            <textarea
                                                                className="form-control"
                                                                id="description"
                                                                placeholder="Add description"
                                                                rows={3}
                                                                {...field}
                                                            />
                                                        )}
                                                    />
                                                </div>
                                            </div>
                                            <div className="form-group m-0 d-flex align-items-center px-2 mb-3">
                                                <div className="mail-received-check-btn me-2 p-0">
                                                    <div className="checkbox-custom table-check">
                                                        <Controller
                                                            name="sendMailToGuest"
                                                            control={control}
                                                            render={({ field }) => (
                                                                <input
                                                                    className="list-child"
                                                                    type="checkbox"
                                                                    id="sendMailToGuest"
                                                                    checked={field.value}
                                                                    onChange={field.onChange}
                                                                />
                                                            )}
                                                        />
                                                        <label htmlFor="sendMailToGuest" className="label-text" />
                                                    </div>
                                                </div>
                                                <label htmlFor="sendMailToGuest" id="sendMailToGuest" className="control-label m-0 all-day-chaeck">
                                                    Send Mail To Guest
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SimpleBar>
                            <div className="compose-btn-box d-flex align-items-center justify-content-between">
                                <button type="button" className="btn-new" onClick={onClose}> Cancel </button>
                                <SubmitButton className="btn-new btn-new-bg loading-spinner"
                                    onClick={handleSubmit(onSubmit, (errors: any) => {
                                        console.log('SUBMIT BLOCKED BY ERRORS:', errors);
                                    })}
                                >
                                    Save
                                </SubmitButton>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </BaseModal>

    )
}

export default CalendarEventModal;